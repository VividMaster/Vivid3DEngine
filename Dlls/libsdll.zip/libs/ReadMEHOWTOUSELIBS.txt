Unzip all the dlls in libs.zip to any project bin you are trying to compile run.

For StarGame,

unzip to StarGame/Bin/64/Debug/

for ModelEditor

ModelEditor/Bin/64/Debug/


YES, the project requires 64bit windows. Hope that's ok for you all!